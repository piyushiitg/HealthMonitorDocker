yum install python-setuptools
yum install python-devel
yum install libevent-devel

